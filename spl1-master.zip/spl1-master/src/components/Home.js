import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

import PlayerRegistration from './PlayerRegistration';

const Home = () => {
  const [showRegistration, setShowRegistration] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  return (
    <div className="home">
      {/* Title Sponsor Section */}
      <div style={{textAlign:'center',marginTop:24,marginBottom:8}}>
        <div style={{display:'inline-flex',flexDirection:'column',alignItems:'center',gap:4}}>
          <span style={{fontWeight:600,fontSize:'1.08em',color:'#333',marginBottom:2}}>Title Sponsor:</span>
          <div style={{fontFamily:'serif',fontWeight:700,fontSize:'1.25em',color:'#fff',marginTop:10,letterSpacing:'1px',textShadow:'0 1px 4px #0008'}}>IMPERIAL LIFESTYLE</div>
          <div style={{fontStyle:'italic',fontSize:'1.05em',color:'#eee',marginTop:2,marginBottom:2}}>Where your family is our family!</div>
        </div>
      </div>
      <div className="hero-section" style={{display:'flex',justifyContent:'center',alignItems:'center',minHeight:'40px',padding:'2px 0 2px 0',margin:'0 auto',position:'relative',zIndex:2,background:'radial-gradient(circle at 50% 40%, #1a1a2e 60%, #23234d 100%)',borderRadius:'18px',boxShadow:'0 1px 8px #00fff733, 0 1px 0 #ff00ea22'}}>
        {/* Cricket Bat and Ball SVGs - random positions */}
        <svg width="48" height="48" style={{position:'absolute',top:18,left:40,transform:'rotate(-18deg)'}} viewBox="0 0 48 48"><g><rect x="20" y="6" width="8" height="28" rx="3" fill="#e0b97a" stroke="#b8860b" strokeWidth="2"/><rect x="22" y="34" width="4" height="8" rx="2" fill="#b8860b"/><ellipse cx="24" cy="10" rx="3" ry="2" fill="#fff3"/></g></svg>
        <svg width="32" height="32" style={{position:'absolute',top:60,right:60}} viewBox="0 0 32 32"><circle cx="16" cy="16" r="12" fill="#ff3c3c" stroke="#fff" strokeWidth="2"/><ellipse cx="16" cy="16" rx="10" ry="3" fill="#fff2"/></svg>
        <svg width="38" height="38" style={{position:'absolute',bottom:30,left:80,transform:'rotate(12deg)'}} viewBox="0 0 48 48"><g><rect x="20" y="6" width="8" height="28" rx="3" fill="#e0b97a" stroke="#b8860b" strokeWidth="2"/><rect x="22" y="34" width="4" height="8" rx="2" fill="#b8860b"/><ellipse cx="24" cy="10" rx="3" ry="2" fill="#fff3"/></g></svg>
        <svg width="28" height="28" style={{position:'absolute',bottom:24,right:90}} viewBox="0 0 32 32"><circle cx="16" cy="16" r="12" fill="#ff3c3c" stroke="#fff" strokeWidth="2"/><ellipse cx="16" cy="16" rx="10" ry="3" fill="#fff2"/></svg>
        <div className="hero-content" style={{textAlign:'center',width:'100%',position:'relative',zIndex:2}}>
          <div style={{position:'relative',display:'inline-block',marginBottom:18}}>
            <span
              style={{
                display:'block',
                fontSize:'2.7em',
                fontWeight:900,
                letterSpacing:'2.5px',
                color:'#fff',
                padding:'0 32px',
                background:'linear-gradient(90deg,#fff 0%,#ffe066 40%,#00fff7 60%,#ff00ea 100%)',
                WebkitBackgroundClip:'text',
                WebkitTextFillColor:'transparent',
                fontFamily:'Orbitron, Exo, Audiowide, sans-serif',
                textTransform:'uppercase',
                lineHeight:1.1,
                filter:'drop-shadow(0 2px 0 #0008)',
                zIndex:2,
                position:'relative',
              }}
            >
              Welcome to Sankalp Premier League
            </span>
            <span
              style={{
                content:'',
                position:'absolute',
                left:18,
                right:18,
                bottom:8,
                height:18,
                background:'linear-gradient(90deg,#ffe06633 0%,#00fff733 60%,#ff00ea22 100%)',
                borderRadius:12,
                zIndex:1,
                filter:'blur(2.5px)',
                pointerEvents:'none',
              }}
            />
          </div>
          <div
            style={{
              fontSize:'1.25em',
              fontWeight:600,
              color:'#fff',
              background:'linear-gradient(90deg,#ffe066 0%,#00fff7 100%)',
              WebkitBackgroundClip:'text',
              WebkitTextFillColor:'transparent',
              fontFamily:'Exo, Orbitron, Audiowide, sans-serif',
              marginBottom:0,
              letterSpacing:'1.2px',
              textShadow:'0 1.5px 0 #0006',
              padding:'0 18px',
              lineHeight:1.3,
              display:'inline-block',
            }}
          >
            Experience the thrill of cricket like never before
          </div>
        </div>
      </div>
      {/* Modern Sports Keyframes and Fonts */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&family=Exo:wght@700&family=Audiowide&display=swap');
      `}</style>
      
      {/* ...existing code... */}
      {/* Main Buttons Section moved above Sponsored by */}
      <div className="main-buttons" style={{marginTop:'-62px'}}>
        <div className="button-grid">
          <div className="main-button registration-button" onClick={() => setShowRegistration(true)} style={{cursor:'pointer'}}>
            <div className="button-icon">📝</div>
            <h3>Player Registration</h3>
            <p>Register as a player for SPL</p>
          </div>
          <Link to="/live-auction" className="main-button auction-button">
            <div className="button-icon">🏆</div>
            <h3>Live Auction</h3>
            <p>Participate in player auctions</p>
          </Link>
          <Link to="/score-board" className="main-button score-button">
            <div className="button-icon">📊</div>
            <h3>Score Board</h3>
            <p>Check live scores and standings</p>
          </Link>
          <Link to="/squads" className="main-button squad-button">
            <div className="button-icon">👥</div>
            <h3>Squads</h3>
            <p>View team compositions</p>
          </Link>
          <Link to="/scoring" className="main-button scoring-button">
            <div className="button-icon">🎯</div>
            <h3>Scoring</h3>
            <p>Track player performance</p>
          </Link>
        </div>
      </div>
      {/* Sponsored by Label and Sponsor Images Grid */}
      <div style={{textAlign:'center',fontWeight:600,fontSize:'1.15em',letterSpacing:'0.5px',marginTop:32,marginBottom:2,color:'#333'}}>Sponsored by</div>
      <div className="sponsor-row" style={{display:'flex',justifyContent:'center',alignItems:'center',gap:12,margin:'12px 0 24px 0',flexWrap:'wrap'}}>
        {[...Array(8)].map((_, i) => {
          const num = i < 3 ? i+1 : i+1; // sponsor1.jpg to sponsor8.jpg
          const imgSrc = process.env.PUBLIC_URL + `/sponsor${num}.jpg`;
          return (
            <div key={i} style={{flex:'1 1 90px',maxWidth:100,display:'flex',justifyContent:'center',alignItems:'center'}}>
              <img
                src={imgSrc}
                alt={`Sponsor ${num}`}
                style={{width:'70px',height:'70px',objectFit:'contain',borderRadius:8,boxShadow:'0 2px 8px #0001',background:'#fff'}}
              />
            </div>
          );
        })}
      </div>

      <div className="main-buttons">
        <div className="button-grid">
          <div className="main-button registration-button" onClick={() => setShowRegistration(true)} style={{cursor:'pointer'}}>
            <div className="button-icon">📝</div>
            <h3>Player Registration</h3>
            <p>Register as a player for SPL</p>
          </div>
          <Link to="/live-auction" className="main-button auction-button">
            <div className="button-icon">🏆</div>
            <h3>Live Auction</h3>
            <p>Participate in player auctions</p>
          </Link>
          <Link to="/score-board" className="main-button score-button">
            <div className="button-icon">📊</div>
            <h3>Score Board</h3>
            <p>Check live scores and standings</p>
          </Link>
          <Link to="/squads" className="main-button squad-button">
            <div className="button-icon">👥</div>
            <h3>Squads</h3>
            <p>View team compositions</p>
          </Link>
          <Link to="/scoring" className="main-button scoring-button">
            <div className="button-icon">🎯</div>
            <h3>Scoring</h3>
            <p>Track player performance</p>
          </Link>
        </div>
      </div>
      
      <div className="features-section">
        <h2>League Features</h2>
        <div className="features-grid">
          <div className="feature-card">
            <div className="feature-icon">⚡</div>
            <h4>Live Auctions</h4>
            <p>Bid on your favorite players in real-time auctions</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">🏅</div>
            <h4>Team Management</h4>
            <p>Build and manage your dream team</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">📈</div>
            <h4>Performance Tracking</h4>
            <p>Monitor player and team statistics</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">🎮</div>
            <h4>Interactive Experience</h4>
            <p>Engage with live matches and events</p>
          </div>
        </div>
      </div>
      {showRegistration && (
        <PlayerRegistration onClose={() => setShowRegistration(false)} />
      )}
    {/* Footer Section */}
    <footer className="home-footer" style={{marginTop:40, padding:'18px 0', background:'#f8f8f8', borderTop:'1px solid #e0e0e0', textAlign:'center'}}>
      <button
        className="footer-link"
        style={{margin:'0 12px', background:'none', border:'none', color:'#007bff', cursor:'pointer', fontSize:'1em', textDecoration:'underline'}}
        onClick={() => setShowPrivacy(true)}
      >
        Privacy Policy
      </button>
      <button
        className="footer-link"
        style={{margin:'0 12px', background:'none', border:'none', color:'#007bff', cursor:'pointer', fontSize:'1em', textDecoration:'underline'}}
        onClick={() => setShowTerms(true)}
      >
        Terms &amp; Conditions
      </button>
      <button
        className="footer-link"
        style={{margin:'0 12px', background:'none', border:'none', color:'#007bff', cursor:'pointer', fontSize:'1em', textDecoration:'underline'}}
        onClick={() => window.open('https://www.sponsorpage.com', '_blank')}
      >
        Sponsor
      </button>
      <span
        className="footer-link"
        style={{margin:'0 12px', color:'#007bff', fontSize:'1em', fontWeight:500, verticalAlign:'middle'}}
      >
        Support: Jeet Shorey 9833232395
      </span>
    </footer>

    {/* Privacy Policy Modal */}
    {showPrivacy && (
      <div style={{position:'fixed',left:0,top:0,width:'100vw',height:'100vh',background:'rgba(0,0,0,0.35)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center'}}>
        <div style={{background:'#fff',borderRadius:8,padding:32,maxWidth:700,maxHeight:'90vh',overflowY:'auto',boxShadow:'0 2px 16px #0002',position:'relative'}}>
          <button style={{position:'absolute',top:10,right:16,fontSize:22,border:'none',background:'none',cursor:'pointer'}} onClick={()=>setShowPrivacy(false)}>&times;</button>
          <h2 style={{marginBottom:8}}>🛡️ Privacy Policy</h2>
          <div style={{fontSize:'1.05em',textAlign:'left'}}>
            <b>Effective Date:</b> July 31, 2025<br/>
            <b>Organizer:</b> Jeet Shorey (shoreyjeet@gmail.com)
            <ol style={{marginTop:16}}>
              <li><b>Introduction</b><br/>Sankalp Premier League (SPL) values your privacy. This policy explains how we collect, use, and protect your personal data during the registration and participation process for SPL, including live auctions and events.</li>
              <li><b>Data We Collect</b><br/>
                <ul>
                  <li>Personal Information: Name, age, phone number, email address, address.</li>
                  <li>Cricket Information: Player role, experience, past teams/clubs.</li>
                  <li>Transaction Data: Payment details during registration or auctions (via secure third-party platforms).</li>
                  <li>Device Info: IP address, browser type (for online auction viewers or participants).</li>
                </ul>
              </li>
              <li><b>How We Use Your Data</b><br/>
                <ul>
                  <li>To manage tournament registration and player eligibility.</li>
                  <li>To conduct and display auction details (e.g. names, teams, base price).</li>
                  <li>To communicate event-related information (via email, WhatsApp, or phone).</li>
                  <li>For internal analytics and event improvements.</li>
                </ul>
              </li>
              <li><b>Data Sharing</b><br/>
                We do not sell your data. Limited data may be shared:
                <ul>
                  <li>With team managers or organizers for auction and team formation.</li>
                  <li>With payment gateways for secure processing.</li>
                  <li>With legal authorities if required by law.</li>
                </ul>
              </li>
              <li><b>Data Security</b><br/>We use secure servers, encrypted storage, and trusted platforms to protect your data. However, no system is 100% immune, so we encourage users to avoid sharing sensitive personal info beyond what's necessary.</li>
              <li><b>Your Rights</b><br/>
                You may request:
                <ul>
                  <li>Access to your data</li>
                  <li>Correction of inaccurate data</li>
                  <li>Deletion of your data (subject to event status)</li>
                </ul>
                To do so, contact: <a href="mailto:shoreyjeet@gmail.com">shoreyjeet@gmail.com</a>
              </li>
            </ol>
          </div>
        </div>
      </div>
    )}

    {/* Terms & Conditions Modal */}
    {showTerms && (
      <div style={{position:'fixed',left:0,top:0,width:'100vw',height:'100vh',background:'rgba(0,0,0,0.35)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center'}}>
        <div style={{background:'#fff',borderRadius:8,padding:32,maxWidth:700,maxHeight:'90vh',overflowY:'auto',boxShadow:'0 2px 16px #0002',position:'relative'}}>
          <button style={{position:'absolute',top:10,right:16,fontSize:22,border:'none',background:'none',cursor:'pointer'}} onClick={()=>setShowTerms(false)}>&times;</button>
          <h2 style={{marginBottom:8}}>📜 Terms and Conditions (T&amp;C)</h2>
          <div style={{fontSize:'1.05em',textAlign:'left'}}>
            <b>SPL – Sankalp Premier League Cricket Tournament &amp; Auction Live</b>
            <ol style={{marginTop:16}}>
              <li><b>Eligibility</b><br/>
                Open to individuals aged 16 and above.<br/>
                Players must register with accurate and verifiable details.<br/>
                Organizers reserve the right to verify identity and deny entry if rules are breached.
              </li>
              <li><b>Registration &amp; Fees</b><br/>
                Registration is only valid upon successful payment.<br/>
                Fees are non-refundable except in case of event cancellation by the organizer.
              </li>
              <li><b>Player Auction</b><br/>
                Players will be auctioned live via an online/offline platform.<br/>
                Bidding teams must follow SPL auction rules shared prior to the event.<br/>
                Final team decisions are binding.
              </li>
              <li><b>Code of Conduct</b><br/>
                Players and team members must exhibit sportsmanship on and off the field.<br/>
                Abuse, cheating, or violence will lead to disqualification.<br/>
                SPL reserves the right to ban or remove participants violating the code of conduct.
              </li>
              <li><b>Media Release</b><br/>
                By participating, you consent to:
                <ul>
                  <li>Use of your photos/videos in SPL promotions or broadcasts.</li>
                  <li>Name and team being listed on websites, social media, or streams.</li>
                </ul>
              </li>
              <li><b>Event Changes</b><br/>
                SPL reserves the right to:
                <ul>
                  <li>Reschedule matches</li>
                  <li>Change venues</li>
                  <li>Modify rules in case of unforeseen circumstances</li>
                </ul>
                All changes will be communicated through official channels (email, WhatsApp, or website).
              </li>
              <li><b>Liability</b><br/>
                SPL and its organizers are not responsible for:
                <ul>
                  <li>Personal injuries during matches</li>
                  <li>Loss or theft of personal belongings</li>
                  <li>Technical issues during live auction streams</li>
                </ul>
              </li>
              <li><b>Contact</b><br/>
                For any questions, email the organizer:<br/>
                <a href="mailto:shoreyjeet@gmail.com">shoreyjeet@gmail.com</a>
              </li>
            </ol>
          </div>
        </div>
      </div>
    )}
  </div>
  );
};

export default Home;